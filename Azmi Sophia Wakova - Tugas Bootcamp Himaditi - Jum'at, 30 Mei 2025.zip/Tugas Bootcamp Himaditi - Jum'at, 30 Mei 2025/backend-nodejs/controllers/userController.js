const bcrypt = require('bcryptjs');

// Data user hard-coded
const users = [
  {
    id: 1,
    name: 'John Doe',
    username: 'johndoe',
    password: 'password123', // akan di-hash
    createdAt: new Date('2023-01-01T10:00:00Z'),
    updatedAt: new Date('2023-01-01T10:00:00Z'),
  },
  {
    id: 2,
    name: 'Jane Smith',
    username: 'janesmith',
    password: 'mypassword', // akan di-hash
    createdAt: new Date('2023-02-01T11:00:00Z'),
    updatedAt: new Date('2023-02-01T11:00:00Z'),
  },
];

// Fungsi untuk hash password menggunakan bcryptjs AES (bcryptjs menggunakan bcrypt algorithm, bukan AES, tapi sesuai permintaan kita gunakan bcryptjs)
const hashPassword = (plainPassword) => {
  const salt = bcrypt.genSaltSync(10);
  return bcrypt.hashSync(plainPassword, salt);
};

// Controller untuk GET /users
const getUsers = (req, res) => {
  // Hash password setiap user sebelum dikirim
  const usersWithHashedPassword = users.map(user => ({
    ...user,
    password: hashPassword(user.password),
  }));

  res.json(usersWithHashedPassword);
};

module.exports = {
  getUsers,
};
