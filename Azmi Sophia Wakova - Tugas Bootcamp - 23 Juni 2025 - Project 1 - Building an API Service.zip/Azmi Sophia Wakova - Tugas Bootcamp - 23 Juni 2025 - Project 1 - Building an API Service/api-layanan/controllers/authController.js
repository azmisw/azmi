const User = require('../models/User');
const jwt = require('jsonwebtoken');

// Daftar pengguna baru
exports.register = async (req, res) => {
  try {
    const { name, email, password } = req.body;
    
    // Cek apakah email sudah terdaftar
    let user = await User.findOne({ email }).notDeleted();
    if (user) {
      return res.status(400).json({ msg: 'User already exists' });
    }

    // Buat user baru
    user = new User({ name, email, password });
    await user.save();

    // Buat token JWT
    const payload = { user: { id: user.id } };
    const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '1h' });

    res.json({ token });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};

// Masuk pengguna
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;
    
    // Cek user
    const user = await User.findOne({ email }).notDeleted();
    if (!user) {
      return res.status(400).json({ msg: 'Invalid credentials' });
    }

    // Cek password
    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(400).json({ msg: 'Invalid credentials' });
    }

    // Cek status aktif
    if (!user.isActive) {
      return res.status(400).json({ msg: 'User is inactive' });
    }

    // Buat token JWT
    const payload = { user: { id: user.id } };
    const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '1h' });

    res.json({ token });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};