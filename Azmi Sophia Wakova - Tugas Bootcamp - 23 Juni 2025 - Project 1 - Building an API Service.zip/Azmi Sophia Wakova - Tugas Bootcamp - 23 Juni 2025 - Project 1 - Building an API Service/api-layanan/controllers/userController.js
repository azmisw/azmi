const User = require('../models/User');

// Dapatkan data pengguna saat ini
exports.getCurrentUser = async (req, res) => {
  try {
    const user = await User.findById(req.user.id)
      .select('-password')
      .notDeleted();
      
    if (!user) {
      return res.status(404).json({ msg: 'User not found' });
    }
    
    res.json(user);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};

// Perbarui data pengguna
exports.updateUser = async (req, res) => {
  try {
    const { name, email } = req.body;
    
    const user = await User.findByIdAndUpdate(
      req.user.id,
      { name, email },
      { new: true }
    )
      .select('-password')
      .notDeleted();
      
    if (!user) {
      return res.status(404).json({ msg: 'User not found' });
    }
    
    res.json(user);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};

// Atur status pengguna
exports.setUserStatus = async (req, res) => {
  try {
    const { isActive } = req.body;
    
    const user = await User.findByIdAndUpdate(
      req.user.id,
      { isActive },
      { new: true }
    )
      .select('-password')
      .notDeleted();
      
    if (!user) {
      return res.status(404).json({ msg: 'User not found' });
    }
    
    res.json(user);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};

// Soft delete pengguna
exports.deleteUser = async (req, res) => {
  try {
    const user = await User.findById(req.user.id).notDeleted();
    
    if (!user) {
      return res.status(404).json({ msg: 'User not found' });
    }
    
    await user.softDelete();
    res.json({ msg: 'User deleted successfully' });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};