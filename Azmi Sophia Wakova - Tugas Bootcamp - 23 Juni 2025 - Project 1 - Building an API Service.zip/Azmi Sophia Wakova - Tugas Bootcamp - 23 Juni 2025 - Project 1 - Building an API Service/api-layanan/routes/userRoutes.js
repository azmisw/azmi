const express = require('express');
const router = express.Router();
const auth = require('../middlewares/authMiddleware');
const {
  getCurrentUser,
  updateUser,
  setUserStatus,
  deleteUser
} = require('../controllers/userController');

// @route   GET api/users/me
// @desc    Get current user
// @access  Private
router.get('/me', auth, getCurrentUser);

// @route   PUT api/users/me
// @desc    Update current user
// @access  Private
router.put('/me', auth, updateUser);

// @route   PATCH api/users/me/status
// @desc    Set user status
// @access  Private
router.patch('/me/status', auth, setUserStatus);

// @route   DELETE api/users/me
// @desc    Delete current user (soft delete)
// @access  Private
router.delete('/me', auth, deleteUser);

module.exports = router;